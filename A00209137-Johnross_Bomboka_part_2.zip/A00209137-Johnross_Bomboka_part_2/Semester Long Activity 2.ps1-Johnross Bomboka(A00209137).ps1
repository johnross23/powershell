Clear-Host
Write-Host JOHNROSS BOMBOKAs SCRIPT -ForegroundColor Green
#Description about the script 
Write-Host  This Script will produce a file containing several random employee names that can be used to the next question
#new function being created 
function New-EmployeeShare ($path ,  $num) {
#the function that will get the number of employees between 10 and 40  and return them 
  function Get-RandomUsers {
    $body = @{
        nat      = 'us'
        results  = $count
    }

    $randomUsers = Invoke-WebRequest -Uri 'https://randomuser.me/api/' -Body $body -Method Get | ConvertFrom-Json
    
    return $randomUsers.results
}
$correctpath = Split-Path -Path "C:\reports\sample2.txt" -Leaf
$testpath = Test-Path "C:\reports\sample2.txt"
#if argument to  test path 
if ($path-eq $correctpath )
{
    Write-Host $testpath
}

else {
    Write-Host "Please type the rigth path "
}
 Get-RandomUsers $correctpath | Export-Csv C:\reports\sample2.txt
$path = Read-Host "What is the path of folder " 
if ($path -eq "C:\reports\sample2.txt")
{

}
else {
    Write-Host "Try again" -BackgroundColor Cyan
}

$users +=  [PSCustomObject]@{
   FirstName = $randomUser.name.first
   LastName  = $randomUser.name.last
   
}
}
New-EmployeeShare $path $correctpath

Clear-Host
Write-Host JOHNROSS BOMBOKAs SCRIPT -ForegroundColor Green
#Description about the script 
Write-Host  This Script will produce a file containing several random employee names that can be used to the next question
#new function being created 
function New-EmployeeFile ($path ,  $num) {
#the function that will get the number of employees between 10 and 40  and return them 
  function Get-RandomUsers([int]$count = 1) {
    $body = @{
        nat      = 'us'
        results  = $count
    }

    $randomUsers = Invoke-WebRequest -Uri 'https://randomuser.me/api/' -Body $body -Method Get | ConvertFrom-Json
    
    return $randomUsers.results
}
$num = Read-Host "How many Employess do you need between 10 and 40 "
#if argument to choose between 10 and 40 
if ($num -ge 10 )
{
    Write-Host $randomUsers 
}
elseif($num -le 40)
 {
    Write-Host $randomUsers
}
else {
    Write-Host "Please type a number between 10 and 40 "
}
Get-RandomUsers $num | Select-Object  @{name="Title";expression={$_.title}} , @{name="Firstname";expression={$_.name.first}} , @{name="Lastname";expression={$_.name.last}} , @{name="Gender";expression={$_.gender}} | Export-Csv C:\reports\sample.txt
$path = Read-Host "What is the path of folder " 
if ($path -eq "C:\reports\sample.txt")
{

}
else {
    Write-Host "Try again" -BackgroundColor Cyan
}
}
New-EmployeeFile $path $num
